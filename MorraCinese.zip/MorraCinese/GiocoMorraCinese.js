alert("Sono Javascript e sono pronto a servirti.");
var nomeGiocatore = window.prompt("Ciao, inserisci il tuo nome: ");
document.getElementById("titolo").innerHTML = "Benvenuto, " + nomeGiocatore + "!";
var sceltaUtente;
function cliccatoSasso() {
    sceltaUtente = "sasso";
    alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}
function cliccatoCarta() {
    sceltaUtente = "carta";
    alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}
function cliccatoForbici() {
    sceltaUtente = "forbici";
    alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}
function verdetto() {
    document.getElementById("sasso").style.display = 'none';
    document.getElementById("carta").style.display = 'none';
    document.getElementById("forbici").style.display = 'none';
    document.getElementById("pulsante").style.display = 'none';
    var sceltaComputer;
    if(sceltaUtente == "sasso"){
        sceltaComputer = "carta";
}
    if(sceltaUtente == "carta"){
        sceltaComputer = "forbici";
}
    if(sceltaUtente == "forbici"){
        sceltaComputer = "sasso";
}
document.getElementById("titolo").innerHTML = nomeGiocatore + ", hai perso!";
document.getElementById("informazioni").innerHTML = "Il computer ha scelto " + sceltaComputer + ". Tu, invece, hai scelto " + sceltaUtente + ".";
}